#include "r_macro.h"
#include "r_spi_if.h" 
#include "iodefine.h"
#include "Detect_Switch.h"
#include "Actions_for_switch.h"

extern Sw;
//Initial status of press 1// 
int previous1=1;
int current1=1 ;
int counting_edge1=0;

//Initial status of press 2//
int previous2=1;
int current2=1 ;
int counting_edge2=0;

//Initial status of press 3//
int previous3=1;
int current3=1 ;
int counting_edge3=0;

//Initial status of press 1&2 in the sametime//
int previous4=1;
int current4=1 ;
int counting_edge4=0;
/*********************************************************************************************
* Function Name: Detect_Switch
* Description  : Check chattering and detect which switch is pressed, actions for each switch
* Arguments    : none
* Return Value : none
*********************************************************************************************/

void Detect_Switch(void) {
	    //Waiting for 1ms to get sample from Switch 1, Switch 2, Switch 3
	    unsigned long i =1*1778; 
            while (i!=0) i--;
	    
	    /* Check if button 1 are pressed */
	    previous1 = current1;
	    if ((P7&0x40) != 0x40)
	    {   
	        current1= 0; //update status of Switch 1 if switch 1 is pressed	
	    } else {current1 = 1; //update status of Switch 1 if switch 1 is not pressed
	    }	
	    if((current1==0) && (previous1==1)){ // If Switch is changed from "not pressed" to "pressed", update counter of negedge 
		    counting_edge1=counting_edge1+1; 
		    if (counting_edge1 >= 1){
		        counting_edge1 =0;
			Sw=1;
			Actions_for_switch();
			}
		}
	    
	    
	    /* Check if button 2 are pressed */  
	        previous2 = current2;
	    if ((P7&0x10) != 0x10)
	    {   
	        current2= 0; //update status of Switch 2 if Switch 2 is pressed		
	    } else {current2 = 1;  //update status of Switch 2 if switch 2 is not pressed
	    }
	    if((current2==0) && (previous2 ==1)){ // If Switch 2 is changed from "not pressed" to "pressed", update counter of negedge 
		    counting_edge2=counting_edge2+1;
		    if (counting_edge2 >= 1){
		        counting_edge2 =0;
			Sw=2;
			Actions_for_switch();
			}
		}
	    
	    
	       
	    /* Check if button 3 are pressed */
	        previous3 = current3;//update status of Switch 3 if Switch 3 is pressed	
	    if ((P7&0x20) != 0x20)
	    {   
	        current3= 0;	
	    } else {current3 = 1; //update status of Switch 3 if switch 3 is not pressed
	    }
	    if((current3==0) && (previous3 ==1)){  // If Switch 3 is changed from "not pressed" to "pressed", update counter of negedge 
		    counting_edge3=counting_edge3+1;
		    if (counting_edge3 >= 1){
		        counting_edge3 =0;
		          Sw=3;// detect switch 3
			  Actions_for_switch();//actions for switch 3
		}
	    } 
	    
	    /* Check if button 1 and 2 are pressed in the same time*/ 
		previous4 = current4;
	    if ((P7&0x40) != 0x40 && (P7&0x10) != 0x10)
	    {   
	        current4= 0;	
	    } else {current4 = 1;
	    }
	    if((current4==0) && (previous4==1)){
		    counting_edge4=counting_edge4+1;
		    if (counting_edge4 >= 1){
		        counting_edge4 =0;
		        Sw=4;
			Actions_for_switch();
		}
	    }           
	}