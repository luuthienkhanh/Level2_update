
#include"lcd.h"
#include"Display_status.h"
#include"timer.h"
#define PAUSING 1
#define RUNNING 2
#define FIRST_RECORD 3
#define LAST_RECORD 4
#define NO_RECORD 5
unsigned long t =10*1778;
extern int time_temp;
               

void Display_status (int G_TimeDisplay_t, int status_t,int action_t){
if (status_t==NO_RECORD){
	if (action_t!=PAUSING){
	if (0<G_TimeDisplay_t){
		DisplayLCD(LCD_LINE1, (uint8_t *)"No record");
	}else {DisplayLCD(LCD_LINE1, (uint8_t *)"Running..");
		status_t==0;
	}
        } else if(0<time_temp){
		 DisplayLCD(LCD_LINE1, (uint8_t *)"No record");
		 while (t!=0) t--;
		 t =10*1778;
		 time_temp--;
	        }else {
			 DisplayLCD(LCD_LINE1, (uint8_t *)"Pausing..");
			 time_temp=0;
			 status_t=0;
		 }
               }


if (status_t==FIRST_RECORD){
	if (action_t!=PAUSING){
	if (0<G_TimeDisplay_t){
		DisplayLCD(LCD_LINE1, (uint8_t *)"First Record");
	}else {DisplayLCD(LCD_LINE1, (uint8_t *)"Running..");
		status_t==0;
	}
        } else{
		if (0<G_TimeDisplay_t){
		DisplayLCD(LCD_LINE1, (uint8_t *)"First Record");
	        }else {DisplayLCD(LCD_LINE1, (uint8_t *)"Pausing..");
		status_t==0;
		EI();
                timer_stop();
	}
	}
}


if (status_t==LAST_RECORD){
	if (action_t!=PAUSING){
	if (0<G_TimeDisplay_t){
		DisplayLCD(LCD_LINE1, (uint8_t *)"Last Record");
	}else {DisplayLCD(LCD_LINE1, (uint8_t *)"Running..");
		status_t==0;
	}
        } else{
		if (0<G_TimeDisplay_t){
		DisplayLCD(LCD_LINE1, (uint8_t *)"Last Record");
	        }else {DisplayLCD(LCD_LINE1, (uint8_t *)"Pausing..");
		status_t==0;
		EI();
                timer_stop();
	}
	}
}

}
