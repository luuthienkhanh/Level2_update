#include "r_macro.h"  /* System macro and standard type definition */
#include "timer.h"    /* Timer driver interface */
#include "lcd.h"      /* LCD driver interface */ 
#include "scroll.h"
#include "Display_record.h"

extern time_t time;
extern int record_time;
extern time_t time_record[20];
void scroll_down(int move){
	int i;
	if (record_time>=6){
	for (i=0; i<=5;i++){
	Display_record(time_record[record_time-1-move-i],7-i,record_time-1-move-i);
        }
	}
	
}
