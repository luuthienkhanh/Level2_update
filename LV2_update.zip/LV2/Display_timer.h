
void Display_timer(time_t, int);
